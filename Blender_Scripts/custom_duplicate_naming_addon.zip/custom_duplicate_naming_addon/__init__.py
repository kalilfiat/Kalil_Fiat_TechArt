bl_info = {
    "name": "Custom Duplicate Naming + ShiftD Toggle",
    "author": "OpenAI",
    "version": (1, 2, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Rename Dup",
    "description": "Duplicate with custom naming and assign/unassign Shift+D",
    "category": "Object",
}

import bpy
import re
from string import ascii_uppercase
from bpy.props import EnumProperty, IntProperty, PointerProperty


addon_keymaps = []


def strip_custom_suffix(name: str) -> str:
    patterns = [
        r"\.\d+$",
        r"[-_]\d+$",
        r"[-_][A-Z]+$",
    ]
    base = name
    for p in patterns:
        base = re.sub(p, "", base)
    return base


def number_to_letters(index: int) -> str:
    result = ""
    while index > 0:
        index -= 1
        result = ascii_uppercase[index % 26] + result
        index //= 26
    return result


def build_candidate_name(base: str, separator: str, counter_mode: str, digits: int, index: int) -> str:
    if counter_mode == "LETTER":
        suffix = number_to_letters(index)
    else:
        suffix = str(index).zfill(digits)
    return f"{base}{separator}{suffix}"


def get_used_object_names():
    return {obj.name for obj in bpy.data.objects}


def find_next_available_name(base: str, separator: str, counter_mode: str, digits: int, used_names: set) -> str:
    index = 1
    while True:
        candidate = build_candidate_name(base, separator, counter_mode, digits, index)
        if candidate not in used_names:
            return candidate
        index += 1


def duplicate_object_direct(obj, linked_data=False):
    new_obj = obj.copy()

    if obj.data:
        if linked_data:
            new_obj.data = obj.data
        else:
            new_obj.data = obj.data.copy()

    if obj.animation_data and obj.animation_data.action:
        try:
            new_obj.animation_data_create()
            new_obj.animation_data.action = obj.animation_data.action.copy()
        except Exception:
            pass

    if obj.users_collection:
        for col in obj.users_collection:
            col.objects.link(new_obj)
    else:
        bpy.context.scene.collection.objects.link(new_obj)

    new_obj.matrix_world = obj.matrix_world.copy()
    return new_obj


def ensure_only_selected(context, objects, active=None):
    for obj in context.selected_objects:
        obj.select_set(False)

    for obj in objects:
        obj.select_set(True)

    if active and active.name in bpy.data.objects:
        context.view_layer.objects.active = active
    elif objects:
        context.view_layer.objects.active = objects[0]


def get_object_mode_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.user
    if not kc:
        return None
    km = kc.keymaps.get("Object Mode")
    if not km:
        km = kc.keymaps.new(name="Object Mode", space_type='EMPTY')
    return km


def shift_d_is_assigned():
    km = get_object_mode_keymap()
    if not km:
        return False

    for kmi in km.keymap_items:
        if (
            kmi.idname == "object.duplicate_custom_named"
            and kmi.type == 'D'
            and kmi.value == 'PRESS'
            and kmi.shift
            and kmi.active
        ):
            return True

    return False


def add_shift_d_keymap():
    km = get_object_mode_keymap()
    if not km:
        return False, "No se pudo acceder al keymap de Object Mode"

    for kmi in km.keymap_items:
        if (
            kmi.idname == "object.duplicate_custom_named"
            and kmi.type == 'D'
            and kmi.value == 'PRESS'
            and kmi.shift
        ):
            kmi.active = True
            return True, "Ya estaba asignado"

    for kmi in km.keymap_items:
        if kmi.type == 'D' and kmi.value == 'PRESS' and kmi.shift:
            if kmi.idname in {
                "object.duplicate_move",
                "object.duplicate_move_linked",
            }:
                kmi.active = False

    kmi = km.keymap_items.new(
        "object.duplicate_custom_named",
        type='D',
        value='PRESS',
        shift=True,
    )
    addon_keymaps.append((km, kmi))

    return True, "Asignado a Shift + D"


def remove_shift_d_keymap():
    km = get_object_mode_keymap()
    if not km:
        return False, "No se pudo acceder al keymap de Object Mode"

    to_remove = []
    for kmi in km.keymap_items:
        if (
            kmi.idname == "object.duplicate_custom_named"
            and kmi.type == 'D'
            and kmi.value == 'PRESS'
            and kmi.shift
        ):
            to_remove.append(kmi)

    for kmi in to_remove:
        km.keymap_items.remove(kmi)

    for kmi in km.keymap_items:
        if kmi.type == 'D' and kmi.value == 'PRESS' and kmi.shift:
            if kmi.idname in {
                "object.duplicate_move",
                "object.duplicate_move_linked",
            }:
                kmi.active = True

    addon_keymaps[:] = [
        (stored_km, stored_kmi)
        for stored_km, stored_kmi in addon_keymaps
        if stored_kmi not in to_remove
    ]

    return True, "Desasignado de Shift + D"


class CDN_Properties(bpy.types.PropertyGroup):
    separator: EnumProperty(
        name="Separador",
        items=[
            (".", ".", "Ej: Cube.001"),
            ("_", "_", "Ej: Cube_001"),
            ("-", "-", "Ej: Cube-001"),
        ],
        default="-",
    )

    counter_mode: EnumProperty(
        name="Contador",
        items=[
            ("NUMBER", "Número", "Usar números"),
            ("LETTER", "Letra", "Usar letras"),
        ],
        default="NUMBER",
    )

    digits: IntProperty(
        name="Dígitos",
        description="Cantidad de dígitos para números",
        default=3,
        min=1,
        max=6,
    )


class OBJECT_OT_duplicate_custom_named(bpy.types.Operator):
    bl_idname = "object.duplicate_custom_named"
    bl_label = "Duplicate Custom Named"
    bl_description = "Duplicate selected objects with custom naming"
    bl_options = {"REGISTER", "UNDO"}

    linked_data: bpy.props.BoolProperty(
        name="Linked Data",
        default=False,
        description="If enabled, duplicate shares object data like Alt+D",
    )

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'WARNING'}, "Este operador funciona en Object Mode")
            return {'CANCELLED'}

        selected_before = list(context.selected_objects)
        active_before = context.view_layer.objects.active

        if not selected_before:
            self.report({'WARNING'}, "No hay objetos seleccionados")
            return {'CANCELLED'}

        props = context.scene.cdn_props
        used_names = get_used_object_names()
        new_objects = []

        for obj in selected_before:
            base = strip_custom_suffix(obj.name)

            new_name = find_next_available_name(
                base=base,
                separator=props.separator,
                counter_mode=props.counter_mode,
                digits=props.digits,
                used_names=used_names,
            )

            new_obj = duplicate_object_direct(obj, linked_data=self.linked_data)
            new_obj.name = new_name
            used_names.add(new_name)
            new_objects.append(new_obj)

        new_active = None
        if active_before in selected_before:
            try:
                idx = selected_before.index(active_before)
                new_active = new_objects[idx]
            except Exception:
                new_active = new_objects[0] if new_objects else None
        elif new_objects:
            new_active = new_objects[0]

        ensure_only_selected(context, new_objects, new_active)
        bpy.ops.transform.translate('INVOKE_DEFAULT')

        return {'FINISHED'}


class WM_OT_toggle_custom_shift_d(bpy.types.Operator):
    bl_idname = "wm.toggle_custom_shift_d"
    bl_label = "Toggle Custom Shift+D"
    bl_description = "Assign or unassign custom duplicate operator to Shift+D"

    def execute(self, context):
        if shift_d_is_assigned():
            ok, msg = remove_shift_d_keymap()
        else:
            ok, msg = add_shift_d_keymap()

        if ok:
            self.report({'INFO'}, msg)
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}


class VIEW3D_PT_custom_duplicate_naming(bpy.types.Panel):
    bl_label = "Rename Dup"
    bl_idname = "VIEW3D_PT_custom_duplicate_naming"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Rename Dup"

    def draw(self, context):
        layout = self.layout
        props = context.scene.cdn_props

        col = layout.column(align=True)

        col.label(text="Separador")
        row = col.row(align=True)
        row.prop(props, "separator", expand=True)

        col.separator()

        col.label(text="Contador")
        row = col.row(align=True)
        row.prop(props, "counter_mode", expand=True)

        if props.counter_mode == "NUMBER":
            col.prop(props, "digits")

        preview_box = col.box()
        preview_box.label(text="Vista previa")
        if props.counter_mode == "NUMBER":
            preview_box.label(text=f"Objeto{props.separator}{str(1).zfill(props.digits)}")
        else:
            preview_box.label(text=f"Objeto{props.separator}A")

        col.separator()

        col.operator(
            "object.duplicate_custom_named",
            text="Duplicar con nombre personalizado",
            icon='DUPLICATE'
        ).linked_data = False

        col.operator(
            "object.duplicate_custom_named",
            text="Duplicar linked data",
            icon='LINKED'
        ).linked_data = True

        col.separator()

        is_on = shift_d_is_assigned()
        toggle_text = "Desasignar Shift + D" if is_on else "Asignar Shift + D"
        toggle_icon = 'CHECKBOX_HLT' if is_on else 'CHECKBOX_DEHLT'
        col.operator("wm.toggle_custom_shift_d", text=toggle_text, icon=toggle_icon)

        status_box = col.box()
        status_box.label(text="Estado actual")
        status_box.label(text="Custom Shift+D: ACTIVO" if is_on else "Custom Shift+D: INACTIVO")


classes = (
    CDN_Properties,
    OBJECT_OT_duplicate_custom_named,
    WM_OT_toggle_custom_shift_d,
    VIEW3D_PT_custom_duplicate_naming,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cdn_props = PointerProperty(type=CDN_Properties)


def unregister():
    try:
        remove_shift_d_keymap()
    except Exception:
        pass

    if hasattr(bpy.types.Scene, "cdn_props"):
        del bpy.types.Scene.cdn_props

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
